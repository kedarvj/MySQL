<?php
	#Function to display slave status.
	function slavestatus($host,$slaveport=3306,$username,$password)
	{
		$con=mysql_connect("$host:$slaveport","$username",$password) or die("can't connect server");
		$result=mysql_query("show slave status");
		$timeResult=mysql_query("select now()");
		$time=mysql_result($timeResult,0,0);
		$reslultArr = array();
		while($status = mysql_fetch_array($result))
		{
			$reslultArr['mhost']=$status[1];
			$reslultArr['mport']=$status[3];
			$reslultArr['file']=$status[5];
			$reslultArr['position']=$status[6];
			$reslultArr['sql_run']=$status[10];
			$reslultArr['io_run']=$status[11];
			$reslultArr['errorNum']=$status[18];
			$reslultArr['errorMeg']=$status[19];
		}
		return $reslultArr;
	}

	#Function for starting and stopping mysql server.
	function start_stop($host,$port,$user,$password,$task='no')
	{
		if($task=='no') 
			exit;
		$dbHost = $host.':'.$port;
		$con=mysql_connect($dbHost,$user,$password) or die("can't connect server while $task");
		$sql= $task . " slave";
		$result = mysql_query($sql);
		return $result;
	}

	#Function for showing detailed status
	function get_status($host,$port,$user,$password)
	{
		$dbHost = $host.':'.$port;
		$con=mysql_connect($dbHost,$user,$password) or die("can't connect server while $task");
		
		$sql="show global status";
		$res=mysql_query($sql);
		$resArr = array();
		while($row = mysql_fetch_assoc($res)) 
		{
			array_push($resArr, $row);
		}
		return $resArr;
	}


	function alert($host)
	{
		$to = "kedar.v@sabsebolo.com";
		$subject = "Replication Issue at: $host!";
		$body = "This is auto generated alert for replication issue at $host. It seems like data is not being replicated.";
		if (mail($to, $subject, $body)) {
			echo("<p>Message successfully sent!</p>");
		} else {
			echo("<p>Message delivery failed...</p>");
		}
	}

?>