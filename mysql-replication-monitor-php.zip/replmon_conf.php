<?php
$config = array( 'Machine1'=>array(
							'host'=>'localhost',
							'port'=>'3306',
							'user'=>'root',
							'password'=>'')
/*
, '2'=>array(
							'host'=>'localhost',
							'port'=>'3306',
							'user'=>'root',
							'password'=>'')
*/
			);
?>