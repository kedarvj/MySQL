<?php
	#Resets warning messages 
	error_reporting(E_ALL ^ E_NOTICE);
	include_once('./replmon_conf.php');
	include_once('./functions.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr">
<title> MySQL Replication Monitor </title>
<?php
if(!isset($_GET['detail']))
{
	#Auto refreshing page for continuous status 
	#content="3;" page refreshes after 3 seconds
	echo '<meta http-equiv="refresh" content="3;">';
}
?>
<body>

	<center>
		<u>MySQL Replication Monitor</u>
		<br/>
		<table border=1>
			<tr>
				<th> host/port </th>
				<th> Master host/port </th>
				<th> file </th>
				<th> position </th>
				<th> io run </th>
				<th> sql run </th>
				<th> errorNum </th>
				<th> errorMeg </th>
				<th> Slave Opr </th>
				<th> Extra </th>
			</tr>
			<?php
				$counter = 0;
				foreach($config as $key => $conf)
				{
					$counter=$key;
					$res = slavestatus($conf['host'],$conf['port'],$conf['user'],$conf['password']);

					echo '
							<tr align=center>
								<td> '.$conf['host'].' : '.$conf['port'].' </td>
								<td> '.$res['mhost'].' : '.$res['mport'].' </td>
								<td> '.$res['file'].' </td>
								<td> '.$res['position'].' </td>
								<td> '.$res['sql_run'].' </td>
								<td> '.$res['io_run'].' </td>
								<td> '.$res['errorNum'].' </td>
								<td> '.$res['errorMeg'].' </td>
								<td> 
									<form name="form" method="POST">
										<input type="submit" name="stop" id="stop" value="stop '.$counter.'">
										<input type="submit" name="start" id="start" value="start '.$counter.'">
									</form>
								</td>
								<td>
									<a href="?detail='.$counter.'"> detailed </a>
								</td>
							</tr>';
		
					if($res['sql_run']=='no'){
						alert($conf['host']);
					}
				}
			?>
		</table>
	</center>
		<?php
			if (isset($_POST['start'])) {
				list($task,$machine)=explode(" ",$_POST['start']);
				echo 'Starting '.$config[$machine]['host'].':'.$config[$machine]['port'];
				$res = start_stop($config[$machine]['host'],$config[$machine]['port'],$config[$machine]['user'],$config[$machine]['password'],$task);
				print_r($res);
			}
			if (isset($_POST['stop'])) {
				list($task,$machine)=explode(" ",$_POST['stop']);
				echo 'Stoping '.$config[$machine]['host'].':'.$config[$machine]['port'];
				$res = start_stop($config[$machine]['host'],$config[$machine]['port'],$config[$machine]['user'],$config[$machine]['password'],$task);
				print_r($res);
			}

			if (isset($_GET['detail'])) {
				echo "<br/>
						<center>
							<b>Showing global status for: ". $_GET['detail'] . "</b>
							<br/>
							<a href=\"".$_SERVER['SCRIPT_NAME']."\">Reset</a></center>
						</center>
					<br/>";
				$machine = $_GET['detail'];
				$result = get_status($config[$machine]['host'],$config[$machine]['port'],$config[$machine]['user'],$config[$machine]['password']);
				
				echo "<table border=1 align=center>
						<tr>
							<th>Variable</th>
							<th>Value</th>
						</tr>";
				foreach($result as $res) 
				{
					echo '<tr align=center><td>'.$res['Variable_name'].'</td><td>'.$res['Value'].'</td></tr>';
				}
				echo "</table>";
			}
		?>
		<div align=right>
			<font face="verdana" color="gray" size="2px">http://kedar.nitty-witty.com</font>
		</div>
	</body>
</html>